package compfinal;

import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JDialog;
import java.util.Scanner;
import javax.swing.*;

public class CompFinal {

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "EVERY ELEMENT MUST BE DIFFERENTIATED BY SPACE EG INT A = 5.\n ACCEPTS INT, FLT & CHR DATA TYPES.\n ; ENDS THE LINE.\n SUPPORTS IF CLAUSE.\n CASE INSENSITIVE(ALL LOWER CASE).\n SUPPORTS ONLY ONE LETTER VARIABLE EG a");
        String size = JOptionPane.showInputDialog("Enter how many lines of code you want :");
        int r = Integer.parseInt(size);
        int res = 0;

        int iter;

        try {
            for (iter = 0; iter < r; iter++) {

                String str = JOptionPane.showInputDialog("Enter string to be tokenized and checked for errors : ");
                char[] arr = str.toCharArray();

                JOptionPane.showMessageDialog(null, arr.length, "No. Of Char", 0);

                determineLexemes(arr);

                int len = str.length();
                System.out.println("Length of String: " + len);

                char c[] = str.toCharArray();

                try {
                    if ((c[0] == 'i' && c[1] == 'n' && c[2] == 't') || (c[0] == 'f' && c[1] == 'l' && c[2] == 't')) {
                        if (Character.isLetter(c[4])) {
                            if (c[6] == '=' && (Character.isLetterOrDigit(c[8])) || (Character.isLetterOrDigit(c[8]) && (c[10] == '+' || c[10] == '-' || c[10] == '*' || c[10] == '/') && Character.isLetterOrDigit(c[12])) || (c[6] == '=' && Character.isDigit(c[8]) && (Character.isDigit(c[9]) || c[9] == '.') && Character.isDigit(c[10]))
                                    || (c[6] == '=' && Character.isDigit(c[8]) && (Character.isDigit(c[9]) || c[9] == '.') && Character.isDigit(c[10]) && (c[12] == '+' || c[12] == '-' || c[12] == '*' || c[12] == '/') && Character.isDigit(c[14]) && (Character.isDigit(c[15]) || c[15] == '.') && Character.isDigit(c[16]))) {
                                System.out.println("No Error.");
                            }
                        }
                    }

                    try {
                        if (c[0] == 'i' && c[1] == 'f' && c[3] == '(' && Character.isLetterOrDigit(c[5]) && (c[7] == '>' || c[7] == '<' || (c[7] == '<' && c[6] == '=') || (c[7] == '>' && c[6] == '=') || (c[7] == '=' && c[8] == '=')) && (Character.isLetterOrDigit(c[10]) || Character.isLetterOrDigit(c[9])) && (c[12] == ')' || c[11] == ')')) {
                            System.out.println("No Error2");
                        }
                    } catch (Exception e) {
                        System.out.println("No Error.");
                    }

                    try {
                        if (c[0] == 'i' && c[1] == 'f' && c[3] == '(' && c[5] == ')' || c[0] == 'i' && c[1] == 'f' && c[3] == '(' && c[5] == ')' && c[7] == '{' && c[9] == '}') {
                            System.out.println("Error1.");
                        }
                    } catch (Exception e) {
                        System.out.println("Error.");
                    }
                    //Vejal
                    if (((c[0] == 'i' && c[1] == 'n' && c[2] == 't') || (c[0] == 'f' && c[1] == 'l' && c[2] == 't')) && c[4] == '=' && c[6] == '\'' && Character.isLetter(c[17]) && c[8] == '\'' /*Character.isAlphabetic(c[6])*/) {
                        System.out.println("Error.");
                    }

                    if (c[0] == 'c' && c[1] == 'h' && c[2] == 'r' && Character.isLetter(c[4]) && c[6] == '=' && Character.isDigit(c[8])) {
                        System.out.println("Error");
                    }

                    if (Character.isLetter(c[0]) && c[2] == '=' && c[4] == ' ') {
                        System.out.println("Error");
                    }

                    try {
                        if ((c[0] != 'i' && c[1] != 'n' && c[2] != 't') || (c[0] != 'f' && c[1] != 'l' && c[2] != 't') || (c[0] != 'c' && c[1] != 'h' && c[2] != 'r')) {
                            if (Character.isLetter(c[4])) {
                                if (c[6] != '=' && (Character.isLetterOrDigit(c[8]))) {
                                    System.out.println("Error4.");
                                }
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("Error.");
                    }
                } catch (Exception e) {
                    System.out.println("Error");
                }

            }
        } catch (Exception e) {
            System.out.println("Error.");
        }

    }

    public static void determineLexemes(char[] arr) {
        try {
            int j = 0;
            //int res=0;

            String[] arrayString = new String[1000];

            String strTwo = "";
            String strThree = "";

            System.out.println("Symbol Table");

            System.out.println("Lexeme\t\tToken");

            for (int i = 0; i < arr.length; i++) {

                if (arr[i] == '+') {
                    System.out.println("+ \t\t ADD_OP");
                }

                inner:
                if (arr[i] == '>') {
                    if (arr[i] == '>' && arr[i + 1] == '=') {
                        System.out.println(">= \t\t Greater_Than_Or_Equal_OP");
                        break inner;
                    }
                    System.out.println("> \t\t Greater_Than_OP");
                }

                outer:
                if (arr[i] == '<') {
                    if (arr[i] == '<' && arr[i + 1] == '=') {
                        System.out.println("<= \t\t Smaller_Than_Or_Equal_OP");
                        int t = 1;
                        break outer;
                    }
                    System.out.println("< \t\t Smaller_Than_OP");
                }

                if (arr[i] == '-') {
                    System.out.println("- \t\t SUB_OP");
                }

                if (arr[i] == '*') {
                    System.out.println("* \t\t MULT_OP");
                }

                if (arr[i] == '/') {
                    System.out.println("/ \t\t DIV_OP");
                }

                if (arr[i] == '(') {
                    System.out.println("( \t\t LEFT_PAREN");
                }

                if (arr[i] == ')') {
                    System.out.println(") \t\t RIGHT_PAREN");
                }

                if (arr[i] == '=' && arr[i - 1] != '<') {
                    i++;
                    if (arr[i] == '=' && arr[i - 1] != '>') {
                        System.out.println("= \t\t EQUAL_OP");
                    }
                    i--;
                    //System.out.println("= \t\t EQUAL_OP");
                }

                if (arr[i] == '=' && arr[i - 1] != '>') {
                    System.out.println("= \t\t EQUAL_OP");
                }

                if (arr[i] == 'i' && arr[i + 1] == 'n' && arr[i + 2] == 't') {
                    System.out.println("INTEGER \t Data Type");
                }

                if (arr[i] == 'f' && arr[i + 1] == 'l' && arr[i + 2] == 't') {
                    System.out.println("FLOAT \t Data Type");
                }

                if (arr[i] == 'c' && arr[i + 1] == 'h' && arr[i + 2] == 'r') {
                    System.out.println("CHARACTER \t Data Type");
                }

                if (Character.isLetter(arr[i]) || Character.isDigit(arr[i])) {

                    strTwo += arr[i];
                } else {
                }

                //if(Character.isDigit(arr[i])||(Character.isDigit(arr[i]) && Character.isDigit(arr[i+1])))
                //{res=res+Character.getNumericValue(arr[i]);}
                if (!Character.isLetter(arr[i]) && !Character.isDigit(arr[i])) {
                    if (!(Character.isWhitespace(arr[i]))) {
                        arrayString[j] = strTwo;
                        System.out.println(arrayString[j] + "\t\t" + "OPERAND");
                        strTwo = "";
                        j++;

                    }
                }
                //System.out.println("Output :"+res);
            }

        } catch (Exception e) {
            System.out.println("Error");
        }
    }

}
