#include<stdio.h>
#include<string.h>
int main()
{
    int i,j,k,length,m,l,l2,l3,n,p,q;
    char str[100],forloop[100],initialize[100],condition[100],increment[100];

    scanf("%[^\n]s",&str);
    length = strlen(str);
    j=0;
    m=0;
    n=0;
    p=0;
    q=0;
    for(i=0; i<length; i++)
    {
        if(str[i] != '(' && j==0)
        {
            forloop[m]= str[i];
            m++;
        }
        else if(str[i]=='(')
        {
            j=1;
        }
        else if( str[i] != ';' && j==1 )
        {
            initialize[n]=str[i];
            n++;
        }
        else if(str[i]== ';' && j==1)
        {
            j=2;

        }
        else if(str[i] != ';' && j==2)
        {
            condition[p]=str[i];
            p++;
        }
        else if(str[i] == ';' && j==2)
        {
            j=3;

        }
        else if(str[i]!= ')' && j==3)
        {
            increment[q]=str[i];
            q++;

        }
        else if(str[i]==')' && j==3)
        {
            j=4;
        }

    }
    forloop[m]='\0';
    initialize[n]='\0';
    condition[p]='\0';
    increment[q]='\0';

    /*  printf("%s\n",forloop);
      printf("%s\n",initialize);
      printf("%s\n",condition);
      printf("%s",increment);*/

    l=strlen(initialize);
    l2=strlen(condition);
    l3=strlen(increment);
    j=0;
    m=0;
    n=0;
    p=0;
    q=0;


/// INITIALIZATION PART:
    for(i=0; i<l; i++)
    {
        if(m==0)
        {
            if((initialize[i] >= '0' && initialize[i] <= '9') && j==0)
            {
                printf("Initialization Error...\n");
                break;
            }
            else if(((initialize[i] >= 'A' && initialize[i] <= 'Z') || (initialize[i] >= 'a' && initialize[i] <= 'z') || initialize[i]== '_' ) && j==2)
            {
                printf("Initialization Error...\n");
                break;
            }
            else if((initialize[i] >= 'A' && initialize[i] <= 'Z') || (initialize[i] >= 'a' && initialize[i] <= 'z') || initialize[i] == '_')
            {
                j=1;
            }
            else if(initialize[i] == ' ' && j==1)
            {
                j=2;
            }
            else if(initialize[i] == '=' || initialize[i] == '+' || initialize[i] == '-' || initialize[i] == '*' || initialize[i] == '/')
            {
                if(initialize[i] =='=')
                {
                    m=1;
                    j=0;
                    if(initialize[i+1] == '\0')
                    {
                        printf("Initialize Error...\n");
                        break;
                    }

                }
                else
                {
                    printf("Initialization Error...\n");
                    break;
                }

            }

        }
        else if(m==1)
        {

            if( initialize[i] >= '0' && initialize[i] <= '9' && j==0)
            {
                j=1;

            }
            else if(((initialize[i] >= 'A' && initialize[i] <= 'Z') || (initialize[i] >= 'a' && initialize[i] <= 'z') || initialize[i]== '_' ) && j==1)
            {

                printf("Initialization Error...\n");
                break;
            }
            else if((initialize[i] >= 'A' && initialize[i] <= 'Z') || (initialize[i] >= 'a' && initialize[i] <= 'z') || (initialize[i] == '_') || (initialize[i] >= '0' && initialize[i] <= '9'))
            {
                if(j==3)
                {

                    printf("Initialization Error...\n");
                    break;
                }
                j=2;

            }
            else if((initialize[i] == ' ' && j==2) || (initialize[i] == ' ' && j==1))
            {
                j=3;

            }
            else if(initialize[i]=='=' || (i==l-1  && j==0))
            {
                printf("Initialization Error...\n");
                break;
            }


        }


    }

    /// CONDITION PART:

    j=0;
    m=0;
    n=0;
    p=0;
    q=0;
    int r=0;

    for(i=0; i<l2; i++)
    {
        if(m==0)
        {
            if((condition[i] >= '0' && condition[i] <= '9') && j==0)
            {

                printf("Condition Error...\n");
                break;
            }
            else if(((condition[i] >= 'A' && condition[i] <= 'Z') || (condition[i] >= 'a' && condition[i] <= 'z') || condition[i]== '_' ) && j==2)
            {

                printf("Condition Error...\n");
                break;
            }
            else if((condition[i] >= 'A' && condition[i] <= 'Z') || (condition[i] >= 'a' && condition[i] <= 'z') || condition[i] == '_')
            {
                j=1;
            }
            else if(condition[i] == ' ' && j==1)
            {
                j=2;
            }
            else if(condition[i] == '=' || condition[i] == '>' || condition[i] == '<' )
            {
                m=1;
                j=0;
                if(condition[i]== '=')
                {
                    q=1;
                    r=1;
                    if(condition[i+1]== '\0')
                    {
                        printf("Condition Part Error...\n");
                        break;
                    }
                }
                else if(condition[i]=='>')
                {
                    q=2;
                    r=1;
                    if(condition[i+1]== '\0')
                    {
                        printf("Condition Part Error...\n");
                        break;
                    }
                }
                else if(condition[i]=='<')
                {
                    q=3;
                    r=1;
                    if(condition[i+1]== '\0')
                    {
                        printf("Condition Part Error...\n");
                        break;
                    }
                }




            }

        }
        else if(m==1)
        {

            if( condition[i] >= '0' && condition[i] <= '9' && j==0)
            {
                j=1;
                q=0;
                r=0;
            }
            else if(condition[i]== ' ' && r==1)
            {
                if(i==l2-1)
                {
                   printf("Condition Part Error...\n");
                   break;
                }

            }
            else if(((condition[i] >= 'A' && condition[i] <= 'Z') || (condition[i] >= 'a' && condition[i] <= 'z') || condition[i]== '_' ) && (j==1 || j==2))
            {

                printf("Condition Error...\n");
                printf("Y");
                break;
            }
            else if((condition[i] >= 'A' && condition[i] <= 'Z') || (condition[i] >= 'a' && condition[i] <= 'z') || (condition[i] == '_') || (condition[i] >= '0' && condition[i] <= '9'))
            {
                if(j==3)
                {

                    printf("Condition Error...\n");
                    printf("a");
                    break;
                }
               // j=2;
                q=0;
                r=0;
            }
            else if((condition[i] == ' ' && j==2) || (condition[i] == ' ' && j==1))
            {
                j=3;
                q=0;
            }
            else if(condition[i] == '=' || condition[i] == '>' || condition[i] == '<' ||condition[i]==' ')
            {
                if((condition[i]=='>' && q==1)|| (condition[i]=='<' && q==1)||(condition[i]=='<' && q==2)|| (condition[i]=='>' && q==3))
                {

                    printf("Condition Error...\n");
                    printf("b");
                    break;
                }

                else if(condition[i]== ' ' && condition[i+1]=='=')
                {

                    printf("Condition Error...\n");
                    printf("c");
                    break;
                }


            }







        }


    }
/// increment OR decrement part:

    j=0;
    m=0;
    n=0;
    p=0;
    q=0;

    for(i=0; i<l3; i++)
    {
        if(m == 0)
        {
            if((increment[i] >= '0' && increment[i] <= '9') && j==0)
            {

                printf("increment part Error...\n");
                break;
            }
            else if(((increment[i] >= 'A' && increment[i] <= 'Z') || (increment[i] >= 'a' && increment[i] <= 'z') || increment[i]== '_' ) && j==2)
            {

                printf("increment part Error...\n");
                break;
            }
            else if((increment[i] >= 'A' && increment[i] <= 'Z') || (increment[i] >= 'a' && increment[i] <= 'z') || increment[i] == '_')
            {
                j=1;
            }
            else if(increment[i] == ' ' && j==1)
            {
                j=2;
            }
            else if(increment[i] == '+')
            {
                m=1;
                j=0;
                q=1;
                n++;
                if(increment[i+1] == '\0')
                {
                    printf("increment part Error...\n");
                    break;
                }
            }
            else if(increment[i] == '-')
            {
                m=1;
                j=0;
                q=2;
                n++;
                if(increment[i+1] == '\0')
                {
                    printf("increment part Error...\n");
                    break;
                }
            }
        }
        else if(m == 1)
        {
            if(increment[i] == ' ' && (q==1 || q==2))
            {
                printf("increment part Error...\n");
                break;
            }
            else if((increment[i] =='+' || increment[i] == '=') && q==1)
            {
                n++;

                if(increment[i+1] == '\0'  && increment[i] == '=')
                {
                    printf("increment part Error...\n");
                    break;
                }
                else if(((increment[i+1] >= 'A' && increment[i+1] <= 'Z') || (increment[i+1] >= 'a' && increment[i+1] <= 'z') || increment[i+1] == '_' || (increment[i+1] >= '0' && increment[i+1] <= '9'))  && increment[i] == '+')
                {
                    printf("increment part Error...\n");
                    break;
                }

                m=2;

            }
            else if((increment[i] =='-' || increment[i] == '=') && q==2)
            {
                n++;
                if(increment[i+1] == '\0'  && increment[i] == '=')
                {
                    printf("increment part Error...\n");
                    break;
                }
                else if(((increment[i+1] >= 'A' && increment[i+1] <= 'Z') || (increment[i+1] >= 'a' && increment[i+1] <= 'z') || increment[i+1] == '_' || (increment[i+1] >= '0' && increment[i+1] <= '9'))  && increment[i] == '-')
                {
                    printf("increment part Error...\n");
                    break;
                }

                m=2;


            }
            else if((increment[i] =='+' && q==2) || (increment[i] =='-' && q==1))
            {
                printf("increment part Error...\n");
                break;
            }


        }
        else if(m==2)
        {
            if( (increment[i] >= '0' && increment[i] <= '9') && j==0)
            {
                j=1;
                q=0;
            }
            else if(((increment[i] >= 'A' && increment[i] <= 'Z') || (increment[i] >= 'a' && increment[i] <= 'z') || increment[i]== '_' ) && j==1)
            {

                printf("increment part Error...\n");
                break;
            }
            else if((increment[i] >= 'A' && increment[i] <= 'Z') || (increment[i] >= 'a' && increment[i] <= 'z') || (increment[i] == '_') || (increment[i] >= '0' && increment[i] <= '9'))
            {
                if(j==3)
                {

                    printf("increment part Error...\n");
                    break;
                }
                j=2;
                q=0;
            }
            else if((increment[i] == ' ' && j==2) || (increment[i] == ' ' && j==1))
            {
                j=3;
                q=0;
            }
            else if(n == 2)
            {
                printf("increment part Error...\n");
                n=0;
                break;
            }
        }
    }


}
