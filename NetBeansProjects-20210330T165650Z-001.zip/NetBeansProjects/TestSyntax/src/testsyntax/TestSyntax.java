/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testsyntax;

import java.util.Scanner;

/*
EVERY ELEMENT MUST BE DIFFERENTIATED BY SPACE EG INT A = 5
ACCEPTS INT, FLT & CHR DATA TYPES
; ENDS THE LINE
SUPPORTS IF CLAUSE
CASE INSENSITIVE(ALL LOWER CASE)

 */
public class TestSyntax {

    public static void main(String[] args) {

        String s = new String();

        Scanner sc = new Scanner(System.in);

        System.out.println("Input the line to be analyzed for error");

        s = sc.nextLine().toLowerCase();
        int len=s.length();
        System.out.println("Length of String: "+len);

        char c[] = s.toCharArray();

        try {
            if ((c[0] == 'i' && c[1] == 'n' && c[2] == 't') || (c[0] == 'f' && c[1] == 'l' && c[2] == 't')) {
                if (Character.isLetter(c[4])) {
                    if (c[6] == '=' && (Character.isLetterOrDigit(c[8])) || (Character.isLetterOrDigit(c[8]) && (c[10] == '+' || c[10] == '-' || c[10] == '*' || c[10] == '/') && Character.isLetterOrDigit(c[12])) || (c[6] == '=' && Character.isDigit(c[8]) && (Character.isDigit(c[9]) || c[9] == '.') && Character.isDigit(c[10]))
                            || (c[6] == '=' && Character.isDigit(c[8]) && (Character.isDigit(c[9]) || c[9] == '.') && Character.isDigit(c[10]) && (c[12] == '+' || c[12] == '-' || c[12] == '*' || c[12] == '/') && Character.isDigit(c[14]) && (Character.isDigit(c[15]) || c[15] == '.') && Character.isDigit(c[16]))) {
                        System.out.println("No Error.");
                    }
                }
            }

            try {
                if (c[0] == 'i' && c[1] == 'f' && c[3] == '(' && Character.isLetterOrDigit(c[5]) && (c[7] == '>' || c[7] == '<' || (c[7] == '<' && c[6] == '=') || (c[7] == '>' && c[6] == '=') || (c[7] == '=' && c[8] == '=')) && (Character.isLetterOrDigit(c[10]) || Character.isLetterOrDigit(c[9])) && (c[12] == ')' || c[11] == ')')) {
                    System.out.println("No Error2");
                }
            } catch (Exception e) {
                System.out.println("No Error.");
            }

            if (c[0] == 'i' && c[1] == 'f' && c[3] == '(' && c[5] == ')' || c[0] == 'i' && c[1] == 'f' && c[3] == '(' && c[5] == ')' && c[7] == '{' && c[9] == '}') {
                System.out.println("Error1.");
            }
            //Vejal
            if (((c[0] == 'i' && c[1] == 'n' && c[2] == 't') || (c[0] == 'f' && c[1] == 'l' && c[2] == 't')) && c[4] == '=' && c[6] == '\'' && Character.isLetter(c[17]) && c[8] == '\'' /*Character.isAlphabetic(c[6])*/) {
                System.out.println("Error.");
            }

            if (c[0] == 'c' && c[1] == 'h' && c[2] == 'r' && Character.isLetter(c[4]) && c[6] == '=' && Character.isDigit(c[8])) {
                System.out.println("Error");
            }

            if (Character.isLetter(c[0]) && c[2] == '=' && c[4] == ' ') {
                System.out.println("Error");
            }
            

            try {
                if ((c[0] != 'i' && c[1] != 'n' && c[2] != 't') || (c[0] != 'f' && c[1] != 'l' && c[2] != 't') || (c[0] != 'c' && c[1] != 'h' && c[2] != 'r')) {
                    if (Character.isLetter(c[4])) {
                        if (c[6] != '=' && (Character.isLetterOrDigit(c[8]))) {
                            System.out.println("Error4.");
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("Error.");
            }
        } catch (Exception e) {
            System.out.println("Error");
        }

    }

}
