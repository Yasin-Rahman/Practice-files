package testcomp;

import java.io.*;
import java.util.Scanner;

public class TestComp {

    public static void main(String[] args) throws IOException {

        InputStreamReader cin = null;
        int i = 0, j;
        int n = 0;
        int k = 0;
        int l = 0;
        int m = 0;
        int o = 0;
        String[] s = new String[50];
        System.out.println("Enter No. of lines you'll write in code");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        System.out.println("Enter characters, ';' to end line.");

        outer:
        for (j = 0; j < n; j++) {
            try {

                cin = new InputStreamReader(System.in);

                char c;
                inner:
                do {
                    c = (char) cin.read();
                    i = j + 1;
                    if (Character.isLetter(c)) {
                        System.out.println("Operand  : " + c);
                    } else if (Character.isDigit(c)) {
                        System.out.println("Literals : " + c);
                        k++;
                        //break inner;

                    } else if (c == '+' || c == '=' || c == '*' || c == '/' || c == '%') {
                        System.out.println("Operator : " + c);
                        l++;
                        //break inner;
                    } else if (c == '.') {
                        System.out.println("Decimal point : " + c);
                        m++;
                        //break inner;
                    } else {
                        System.out.print("");
                        o++;
                        //break inner;
                    }

                    //System.out.print(c);
                } while (c != ';');
                System.out.print("Line:" + i);
                System.out.println("");
            } finally {
                if (cin == null) {
                    cin.close();
                }
            }

        }
        /*if (k != 0 || l != 0 || m != 0 || o != 0) {
            System.out.println("ERROR!");
        }*/

    }
}
