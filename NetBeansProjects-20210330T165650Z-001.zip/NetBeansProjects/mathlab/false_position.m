clc;
clear all;
format long;
f=@(x)(power(x,10)-1);
fxr=@(xl,xu)(xu-(f(xu)*(xl-xu))/(f(xl)-f(xu)));
xl=0;
xu=1.3;
for i=1:1:6
    xr=fxr(xl,xu);
   % disp(xr);
    if(f(xl)*f(xr)<0)
        xu=xr;
    else
        xl=xr;
    end
    disp('XR');
    disp(xr);
    
    if(i>1)
        disp('App Error')
       app_error = (xr-prev)/xr;
       disp(app_error*100);
    end
    prev=xr;
end