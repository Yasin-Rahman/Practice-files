clc;
clear all;
format long;
xi=pi/4;
xi_1 = pi/3;
h= xi_1-xi;
true_value = cos(xi_1);
arr =[cos(xi),-sin(xi),-cos(xi),sin(xi)];
disp('Step');
disp(1);
disp('Result');
res = arr(1);
disp(res);
true_error = (true_value-res)/true_value;
disp('true_error');
disp(true_error*100);
p=2;
for i=1:1:6
    res=res+(arr(p)*(power(h,i))/factorial(i));
    if(p==4)
        p=0;
    end
    disp('res');
    disp(res);
    true_error = (true_value-res)/true_value;
    disp('true_error');
    disp(true_error*100);
    p=p+1;
end
