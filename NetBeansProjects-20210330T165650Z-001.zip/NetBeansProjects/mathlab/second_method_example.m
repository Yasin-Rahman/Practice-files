
%ln(x)
clc;
clear all;
format long;
xi_1=.5;
xi=5;
for i=1:1:6
    disp('Order')
    disp(i);
    disp('f(x-1)')
    fx_1=log(xi_1);
    disp(fx_1)
    disp('f(x)');
    fxi=log(xi);
    disp(fxi);
    disp('xi+1');
    x=xi-((fxi*(xi_1-xi))/(fx_1-fxi));
    disp(x);
    xi_1=xi;
    xi=x;
end