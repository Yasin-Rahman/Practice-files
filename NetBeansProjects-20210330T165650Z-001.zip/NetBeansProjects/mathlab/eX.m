clc;
clear all;
format long;
true_value= 1.648721;
x=.5;
e_x=0;
for i=0:1:6 
    disp('Step')
    disp(i+1);
    p = (power(x,i)/factorial(i));
    e_x= e_x + p;
    disp('Result');
    disp(e_x);
   
    e_t = (true_value-e_x)/true_value;
    disp('true_vale');
    disp(e_t*100);
   
end

