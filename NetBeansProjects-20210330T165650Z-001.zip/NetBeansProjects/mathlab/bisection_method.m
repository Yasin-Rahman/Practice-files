clc;
clear all;
xl=12;
xu=16;
xt=14.79;
fxl=9.8*68.1/xl*(1-exp(-xl/68.1*10))-40;
fxu=9.8*68.1/xu*(1-exp(-xu/68.1*10))-40;
absolute_err = 0.5;
 app_err =0;
if(fxl*fxu<0)
  for i=1:1:7
      disp('Step/Iteration');
      disp(i);
      disp('XL');
      disp(xl);
      disp('XU');     
      disp(xu);
      xr = (xl+xu)/2;
      disp('xr');
      disp(xr);
      if i>1
          disp('Approximation Error');
          app_err = ((xr-xr_prev)/xr)*100;
          disp(app_err);
         
      end
   
      fxl=9.8*68.1/xl*(1-exp(-xl/68.1*10))-40;
      fxr=9.8*68.1/xr*(1-exp(-xr/68.1*10))-40;
      
      if(fxl*fxr<0)
          xu=xr;
      else
          xl=xr;
      end
      true_err = (xt-xr)/xt*100;
      disp('True Error');
      disp(true_err);
        if(abs(app_err )<absolute_err && i>1)
               break;
        end
         xr_prev = xr;
  end

else
    disp('wrong guess');
end
   