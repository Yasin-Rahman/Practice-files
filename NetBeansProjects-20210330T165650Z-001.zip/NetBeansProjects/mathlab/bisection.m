clc;
clear all;
format long;

f=@(x)(x^2-3);
true_value=sqrt(3);
%disp(true_value);
x=1;
x1=2;
for i=1:1:100
    xr=(x+x1)/2;
 
    if f(x)*f(xr)<0
        x1=xr;    
    else
        x=xr;
    end
    disp('xr');
 disp(xr);
 if(i>1)
     disp('App error');
     apperror = (xr-prev)/xr * 100;
     apperror=abs(apperror);
     if(apperror <.01)
         break;
     end
     disp(apperror);
 end
 prev = xr;
end
