clc;
clear all;
xl=0;
xu=2.9;
xt =1;
fxl=power(xl,2)-1;

fxu=power(xu,2)-1;
absolute_err = 5.5;
 app_err =0;
 
 if(fxl*fxu<0)
  for i=1:1:7
      disp('Step/Iteration');
      disp(i);
      disp('XL');
      disp(xl);
      disp('XU');     
      disp(xu);
      xr = (xl+xu)/2;
      disp('xr');
      disp(xr);
      if i>1
          disp('Approximation Error');
          app_err = ((xr-xr_prev)/xr)*100;
          disp(app_err);
         
      end
        fxl=power(xl,2)-1;

        fxr=power(xr,2)-1;
        
      if(fxl*fxr<0)
          xu=xr;
      else
          xl=xr;
      end
      true_err = ((xt-xr)/xt)*100;
      disp('True Error');
      disp(true_err);
        if(abs(app_err )<absolute_err && i>1)
               break;
        end
         xr_prev = xr;
  end

else
    disp('wrong guess');
end

