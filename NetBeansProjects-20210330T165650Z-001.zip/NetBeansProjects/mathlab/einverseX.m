clc;
clear all;
format long;
true_value= 6.737947*10^-3;
x=5;
prev=0;
e_x=0;
p=0;
for i=0:1:6 
    disp('Step')
    disp(i+1);
    p = p + (power(x,i)/factorial(i));
    
    e_x= 1/p;
    disp('Result');
    disp(e_x);
    if (i>0)
       app_error = (e_x - prev)/e_x;
       disp('app_error');
       disp(app_error*100);
       
    end
    e_t = (true_value-e_x)/true_value;
    disp('true_error');
    disp(e_t*100);
    prev=e_x;
   
end

