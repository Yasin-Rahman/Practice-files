%fast order approximation
clc;
clear all;
format long;
xi=1;
xi_1=2;
h=1;
for i=1:1:6
   disp('step size');
   disp(h);
   true_value = power((xi+h),4);
   disp('true_value');
   disp(true_value);
   Istorderapp= power(xi,4) + 4*power(xi,3)*h;
   disp('1st order app');
   disp(Istorderapp);
   disp('Reminder');
   rem= true_value-Istorderapp;
   disp(rem);
   h=h/2;
end
