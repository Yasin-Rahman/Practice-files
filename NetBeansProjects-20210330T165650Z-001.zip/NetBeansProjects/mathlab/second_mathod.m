clc;
clear all;
xi_1=0;
xi=1;
for i=1:1:6
    disp('Order')
    disp(i);
    disp('f(x-1)')
    fx_1=exp(-xi_1)-xi_1;
    disp(fx_1)
    disp('f(x)');
    fxi=exp(-xi)-xi;
    disp(fxi);
    disp('xi+1');
    x=xi-((fxi*(xi_1-xi))/(fx_1-fxi));
    disp(x);
    xi_1=xi;
    xi=x;
end