clc;
clear all;
format long;
f=@(x)(exp(-x)-x);
true_value=0.56714329;
x=0;
xi=1;
for i=1:6
    disp('Iteration');
    disp(i);
    disp('value of x(i+1)= ');
    xii=xi-(f(xi)*(x-xi)/(f(x)-f(xi)));
    disp(xii);
    x=xi;
    xi=xii;
    disp('true error(%)=');
    et=((true_value-xi)/true_value)*100;
    disp(et);
end