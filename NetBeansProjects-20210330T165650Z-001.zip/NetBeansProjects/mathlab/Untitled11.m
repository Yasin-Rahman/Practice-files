%newton_repson
clc;
clear all;
format long;
xi = pi/4;
xi_1=pi/3;
h= xi_1-xi;
true_value= 2*sin(xi_1) + 3*cos(xi_1);
disp(true_value);
arr =[2*sin(xi)+3*cos(xi),2*cos(xi)-3*sin(xi),-2*sin(xi)-3*cos(xi),-2*cos(xi)+3*sin(xi)];
disp('Order');
disp(0);
result=arr(1);
disp(result);
prev = result;
p=2;
for i=1:1:6
    disp('order');
    disp(i);
    result = result + (arr(p)*power(h,i)/factorial(i));
    disp('result');
    disp(result);
    if (p==4)
        p=0;
    end
    disp('App Error');
    apperror = (result-prev)/result;
    disp(apperror*100)
    p=p+1;
    prev=result;
    
end