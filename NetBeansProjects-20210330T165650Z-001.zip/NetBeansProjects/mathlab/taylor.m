clc;
clear all;
format long;
x=pi/4;
x1=pi/3;
h=x1-x;
true_value=sin(x1);
disp(true_value);
disp('order 0 :');
curr= cos (x);
disp('result');
disp(curr);
disp('True_error');
te=((true_value-curr)/true_value)*100;
disp(te);
arr =[sin(x),cos(x),-sin(x),-cos(x)];
p=1;
for i=1:1:6
    p=p+1;
    disp('Order');
    disp(i);
    disp('Current');   
    curr = curr + ((arr(p)*(h^i))/factorial(i));
    disp(curr);
    if(p==4)
        p=0;
   end
   disp('True_error');
   te=((true_value-curr)/true_value)*100;
   disp(te);
   
    
    
end





