/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twogroup;

import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JDialog;

/**
 *
 * @author Shreshto
 */
public class input {
    
    JLabel jl=new JLabel();
    JPanel jp=new JPanel();
    JDialog jd=new JDialog();
    
    
    String str = JOptionPane.showInputDialog("Enter string : ");
    char [] arr = str.toCharArray();

    //JOptionPane.showMessageDialog(null,arr.length);
    
    
}
