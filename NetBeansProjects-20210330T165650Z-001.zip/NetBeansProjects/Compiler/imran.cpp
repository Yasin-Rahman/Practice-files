#include <iostream>
#include<vector>
#include <fstream>
#include <string>
using namespace std;
string tokenizer="",token="";
vector <string>data_type,other;
vector <char>oper;
int p=0;
string q, text,pattern,z;
char charecter_set [] = {'\0','+','-','*','/','=','%','&','#','!','?','^','"','~','|','<','>','(',')','{','}',':',';',',',' '};
string keyword[] = {"auto","break","case","const","vector"
                    "continue","default","do","else",
                    "enum","extern","floatn","for",
                    "goto","if","long","register",
                    "return","short","signed","sizeof",
                    "static","struct","switch","typedef",
                    "union","unsigned","void",
                    "volatile","while",
                   };
string data_type_c[]= {"int","float","double","char","string"};
char number[]= {'0','1','2','3','4','5','6','7','8','9'};
int find_again()
{


    text=token;

    int c, d, e, text_length, pattern_length,check=0 ;

    for(int i=0; i<29; i++)
    {
        pattern=keyword[i];
        text_length   = text.length();
        pattern_length = pattern.length();
        if (pattern_length > text_length)
        {
            continue;
        }

        for (c = 0; c <= text_length - pattern_length; c++)
        {

            e = c;
            for (d = 0; d < pattern_length; d++)
            {
                if (pattern[d] == text[e])
                {
                    e++;


                }
                else
                {
                    break;
                }
            }

            if (d==pattern_length)
            {


                tokenizer += "<"+pattern+",keyword>";

              break;

            }

        }

    }

    for(int i=0; i<5; i++)
    {
        pattern=data_type_c[i];
        pattern_length = pattern.length();
        if (pattern_length > text_length)
        {
            continue;
        }

        for (c = 0; c <= text_length - pattern_length; c++)
        {
           e = c;
            for (d=0; d < pattern_length; d++)
            {
                if (pattern[d] == text[e])
                {
                    e++;
                }
                else
                {
                    break;
                }
            }
            if (d == pattern_length)
            {

                tokenizer += "<"+pattern+",data type>";

            }
        }

    }


}
void check_other()
{
    int len = token.length();
    int cou =0;
    for(int i=0; i<len; i++)
    {
        char c = token[i];
        for(int j=0; j<10; j++)
        {
            if(number[j]==c)
            {
                p++;
                q=c;
                cou++;
            }
        }
    }
    if(cou!=len && p>0)
    {
        tokenizer += "<"+q+",number>";
    }
    if(cou==len)
    {
        tokenizer += "<"+token+",number>";
    }

    else
    {
        tokenizer += "<"+token+",Other>";

        find_again();


    }




}

void check_keyword()
{
    int tag=0;
    for(int i=0; i<30; i++)
    {
        if(keyword[i].compare(token) == 0)
        {
            tokenizer += "<"+token+",keyword>";
            tag=1;
            break;
        }
    }
    if(tag==0)
    {
        check_other();
    }

}
void data_type_check()
{
    int tag=0;
    for(int i=0; i<5; i++)
    {
        if(data_type_c[i].compare(token) == 0)
        {
            tokenizer += "<"+token+",data type>";
            tag=1;
            break;
        }

    }
    if(tag==0)
    {
        check_keyword();
    }
}
int main()
{

    string get_string;
    int i,j,length,tag;
    ofstream myfile;
    myfile.open ("output.txt");
    ifstream input("input.txt");
    while( getline (input,get_string))
    {
        token="";
        tokenizer ="";
        length=get_string.length();
        for(i=0; i<=length; i++)
        {
            tag=0;
            p=0;
            char c=get_string[i];
            for(j=0; j<25; j++)
            {

                if(c==charecter_set[j])
                {
                    if(token=="" && c!='\0')
                    {
                        tokenizer = tokenizer + "<"+get_string[i]+",operator>";
                    }
                    else if(c=='\0' && token!="")
                    {
                        data_type_check();
                    }
                    else if (token !="" && c!='\0')
                    {
                        data_type_check();
                        tokenizer = tokenizer+ "<"+c+",operator>";
                    }

                    tag=1;
                    token="";
                    break;
                }
            }

            if(tag==0)
            {
                token+=get_string[i];
            }
        }
        myfile << tokenizer << endl;
    }
}



