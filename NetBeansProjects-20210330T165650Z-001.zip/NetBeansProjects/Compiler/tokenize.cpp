#include <iostream>
#include<vector>
#include <fstream>
#include <string>
using namespace std;
string tokenizer="",token="";
vector <string>data_type,other;
vector <char>oper;

char charecter_set [] = {'\0','+','-','*','/','=','%','&','#','!','?','^','"','~','|','<','>','(',')','{','}',':',';',',',' '};
string data_type_c[]= {"int","float" ,"double","char"};
void data_type_check()
{ int tag=0;
    for(int i=0; i<4; i++)
    {
        if(data_type_c[i].compare(token) == 0){
                data_type.push_back(data_type_c[i]);
            tag=1;
            break;
        }

    }
    if(tag==0)
    {
        other.push_back(token);
    }
}

int main()
{
    string get_string;
    int i,j,length,tag;
     ifstream input("input.txt");
     getline (input,get_string);
;
    length=get_string.length();
    for(i=0; i<=length; i++)
    {
        tag=0;
        char c=get_string[i];
        for(j=0; j<25; j++)
        {
            if(c==charecter_set[j])
            {
                if(token=="" && c!='\0')
                {
                    tokenizer+=c;
                    oper.push_back(get_string[i]);
                    tokenizer+=',';
                }
                else if(c=='\0' && token!="")
                {
                    tokenizer += token +",";
                    data_type_check();
                }
                else if (token !="")
                {
                    tokenizer += token +"," + get_string[i]+",";
                    oper.push_back(get_string[i]);
                    data_type_check();
                }
                tag=1;
                token="";
                break;
            }
        }
        if(tag==0)
        {
            token+=get_string[i];
        }
    }
    ofstream myfile;
    myfile.open ("output.txt");
    myfile << "Main String :" <<get_string << endl;
    myfile << "After Token :" <<tokenizer << endl ;

    if(oper.size()!=0)
    {
        myfile<< "Operator : ";
        for(i=0; i<oper.size(); i++)
        {

            myfile<<"<"<<oper[i] << ">";
        }
    }
    myfile << endl;
     if(data_type.size()!=0)
    {
        myfile<< "Data Type : " <<" ";
        for(i=0; i<data_type.size(); i++)
        {

            myfile<<"<"<<data_type[i] << ">";
        }
    }
    myfile << endl;
     if(other.size()!=0)
    {
        myfile<< "Other : " <<" ";
        for(i=0; i<other.size(); i++)
        {

            myfile<<"<"<<other[i] << ">";
        }
    }


}

