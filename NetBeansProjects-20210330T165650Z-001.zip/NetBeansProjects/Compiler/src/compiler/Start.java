/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler;
import javax.swing.*;
import java.io.*;

public class Start {
    public static void main(String s[]) throws IOException {
        //JOptionPane jp= new JOptionPane();
        JOptionPane.showMessageDialog(null, "Put the strings to be analyzed in the test.txt file");
        JOptionPane.showMessageDialog(null, "Will not work with a blank text file");
        System.out.println("Reading....");
        Lexer lexer = new Lexer("test.txt");

        while (!lexer.isExausthed()) {
            System.out.printf("%-18s %s\n", lexer.currentToken(), lexer.currentLexema());
            lexer.moveAhead();
        }

        if (lexer.isSuccessful()) {
            System.out.println("Done");
        } else {
            JOptionPane.showMessageDialog(null, lexer.errorMessage() );
            System.out.println("Done");
        }
         
    }
    
} 

