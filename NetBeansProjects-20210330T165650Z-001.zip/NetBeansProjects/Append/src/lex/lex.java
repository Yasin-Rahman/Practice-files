/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lex;

import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JDialog;

public class lex {

    public static void main(String[] args) {
        JLabel jl = new JLabel();
        JPanel jp = new JPanel();
        JDialog jd = new JDialog();

        String str = JOptionPane.showInputDialog("Enter string : ");
        char[] arr = str.toCharArray();

        //JOptionPane.showMessageDialog(null,arr.length);
        JOptionPane.showMessageDialog(null, arr.length, "No. Of Char", 0);

        determineLexemes(arr);

    }

    public static void determineLexemes(char[] arr) {
        int j = 0;

        String[] arrayString = new String[1000];

        String strTwo = "";
        String strThree = "";

        System.out.println("Symbol Table");

        System.out.println("Lexeme\t\tToken");

        for (int i = 0; i < arr.length; i++) {

            if (arr[i] == '+') {
                System.out.println("+ \t\t ADD_OP");
            }

            inner:
            if (arr[i] == '>') {
                if (arr[i] == '>' && arr[i + 1] == '=') {
                    System.out.println(">= \t\t Greater_Than_Or_Equal_OP");
                    int t=1;
                    break inner;
                }
                System.out.println("> \t\t Greater_Than_OP");
            }

            outer:
            if (arr[i] == '<') {
                if (arr[i] == '<' && arr[i + 1] == '=') {
                    System.out.println("<= \t\t Smaller_Than_Or_Equal_OP");
                    int t=1;
                    break outer;
                }
                System.out.println("< \t\t Smaller_Than_OP");
            }

            if (arr[i] == '-') {
                System.out.println("- \t\t SUB_OP");
            }

            if (arr[i] == '*') {
                System.out.println("* \t\t MULT_OP");
            }

            if (arr[i] == '/') {
                System.out.println("/ \t\t DIV_OP");
            }

            if (arr[i] == '(') {
                System.out.println("( \t\t LEFT_PAREN");
            }

            if (arr[i] == ')') {
                System.out.println(") \t\t RIGHT_PAREN");
            }

            if (arr[i] == '=' && arr[i - 1] != '<') {
                i++;
                if (arr[i] == '=' && arr[i - 1] != '>') {
                System.out.println("= \t\t EQUAL_OP1");
                }
                i--;
                 System.out.println("= \t\t EQUAL_OP");
                 
           }
            

            if (arr[i] == '=' && arr[i - 1] != '>') {
                System.out.println("= \t\t EQUAL_OP1");
            }
            
            
            

            if (arr[i] == 'i' && arr[i + 1] == 'n' && arr[i + 2] == 't') {
                System.out.println("INTEGER \t Data Type");
            }
            
            

            if (arr[i] == 'f' && arr[i + 1] == 'l' && arr[i + 2] == 't') {
                System.out.println("FLOAT \t Data Type");
            }

            if (arr[i] == 'c' && arr[i + 1] == 'h' && arr[i + 2] == 'r') {
                System.out.println("CHARACTER \t Data Type");
            }

            if (Character.isLetter(arr[i]) || Character.isDigit(arr[i])) {

                strTwo += arr[i];
            } else {
            }
            
            

            if (!Character.isLetter(arr[i]) && !Character.isDigit(arr[i])) {
                if (!(Character.isWhitespace(arr[i]))) {
                    arrayString[j] = strTwo;
                    System.out.println(arrayString[j] + "\t\t" + "IDENTIFIER/NUMBER");
                    strTwo = "";
                    j++;

                }
            }

        }

    }
}
