/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler1.lexical_analysis;

/**
 *
 * @author Ashraful Alam
 */
public class analysis {
    public static void main(String[] args) {
        lexical ab = new lexical();
       
    }

 
    
}
