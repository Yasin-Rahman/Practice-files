/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler1.lexical_analysis;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.*;

/**
 *
 * @author Ashraful Alam
 */
class lexical {
    
     public lexical(){
          JFrame f = new JFrame();
          f.setBounds(200, 100, 700, 600);
          
          JPanel p1 = new JPanel();
          p1.setBounds(200, 100, 700, 600);
          f.add(p1);
          p1.setLayout(null);
         
          JTextArea ta = new JTextArea();
          ta.setBounds(0, 0, 700, 300);
         // p1.add(ta);
            JScrollPane scrollPane = new JScrollPane(ta);
     scrollPane.setBounds(0,0,680,300);
      scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
      scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
      p1.add(scrollPane);
         /* JScrollBar sb1  = new JScrollBar();
          BoundedRangeModel brm = (BoundedRangeModel) ta.getVisibleRect();
          sb1.setModel(brm);
          p1.add(sb1);*/
          
          
          /*JTextField t1 = new JTextField();
          t1.setBounds(0, 0, 700, 400);
          p1.add(t1);*/
          /*JLabel l1 = new JLabel();
          l1.setBounds(0, 0, 700, 400);
          p1.add(l1);
          l1.setBackground(Color.CYAN);
          l1.setOpaque(true);*/
         
          JButton b1 = new JButton("Compile");
          b1.setBounds(300, 310, 100, 20);
          p1.add(b1);
          
          JTextArea ta1 = new JTextArea();
          ta1.setBounds(0, 350, 700, 250);
          p1.add(ta1);
          
          JScrollPane scrollPane1 = new JScrollPane(ta1);
          scrollPane1.setBounds(0, 350, 680, 230);
          scrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
         // scrollPane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
          p1.add(scrollPane1);
         
          b1.addActionListener(new ActionListener() {

              @Override
              public void actionPerformed(ActionEvent e) {
                  
                  String input = ta.getText();
                  int number=0,j=-1,k=-1,l=-1,i=0;
                  String output = "";
                  int m=0,n=0;
                  int len = input.length();
                  System.out.println("len="+len);
                  int[] constants = new int[len];
                  int[] ascii = new int[len];
                  char[] operators = new char[len];
                  char[][] variables = new char[20][20];
                  int[] pr = new int[len];
                   
                  
                  
                   for( i=0;i<len;i++)
                 {
                     pr[i] = 0;
                 }
                   
                 for(i=0;i<len;++i)
                 {
                     ascii[i] = 0;
                 }
                    
                  
                  System.out.println(""+input);
                  
                  char[] chs = new char[len];
                   chs = input.toCharArray();
                  
                  for ( i = 0; i < len; ++i) {
                      ascii[i] = (int) chs[i];
                  }
                  
                  for(i =0; i < len ; ++i)
                  {
                    
                      if (Character.isDigit(chs[i])) {
                           while(Character.isDigit(chs[i])){
                                number = (10*number) + (ascii[i]-'0');
                                i++;
                           }
                            j++;
                            constants[j] = number;
                            number = 0;
                      }
                      
                      if(Character.isLetter(chs[i])) {
                          while(((Character.isLetter(chs[i])) || (Character.isDigit(chs[i]))) && (i<len) )
                            {
                                    k++;
                                    variables[m][k] =  chs[i];
                                    i++;
                             }
                          
                          m++;
                          pr[n] = k;
                          n++;
                          k = -1;
                           
                         }
                      
                      if (chs[i] == '+' || chs[i] == '-' || chs[i] == '/' || chs[i] == '*' || chs[i] == '=' || chs[i] == '^') {
                          l++;
                          operators[l] = chs[i];

                      }
                      if(chs[i]==' '){
                          continue;
                      }
                      
                  }
                  
                  System.out.println("The literals are:");
                  output = output + "The literals are:"+"\n";
                  for (i = 0; i <= j; i++) {
                      output = output + "\t lit"+(i+1)+"\t"+constants[i]+"\n";
                      //ta1.setText("\t lit"+Integer.toString(i+1)+"\t"+constants[i]+"\n");
                     // System.out.println("\t lit"+(i+1)+"\t "+constants[i]);
                    
                  }
                  
                 
                  
                   System.out.println("The operators are:");
                   output = output + "The operators are:"+"\n";
                  for (i = 0; i <= l; i++) {
                      
                      output = output+"\t op"+(i+1)+"\t"+operators[i]+"\n";
                      //System.out.println("\t lit "+(i+1)+"\t "+operators[i]);
                    
                  }
                  
                  output = output+"The variables are:"+"\n";
                   System.out.println("The variables are:");
                  for (i = 0; i < m; i++) {
                      
                      output = output+"id"+(i+1)+"\t";
                      // System.out.print("id "+(i+1)+"\t");
                      for (j = 0; j <= pr[i]; j++) {
                         
                          output = output+variables[i][j];
                         // System.out.print(""+variables[i][j]);
                      }
                      output = output + "\n";
                     // System.out.println("");
                    
                  }
                  
                  
                   ta1.setText(output);
                  //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
              }
          });
          f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          f.setVisible(true);
         
     }   
}
