import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class testcreate {

	public static void main(String[] args) {
		String dburl= "jdbc:mysql://localhost:3306/try";
		String user="Shreshto";
		String pass="123456";
		try {
		Connection con=DriverManager.getConnection(dburl,user,pass);
		Statement st=con.createStatement();
		String query="CREATE DATABASE cast;";
		ResultSet rs;
		st.executeUpdate(query);
		System.out.println("Created");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
