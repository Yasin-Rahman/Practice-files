import java.sql.*;
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World");
		try{Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "Shreshto", "123456");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("Select  * from testing;");
			while(rs.next()) {
				System.out.println(rs.getInt("id")+","+rs.getString("name"));
			}
	}
		catch(Exception e) {e.printStackTrace();}
}}
