
import java.sql.*;
public class testinsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dburl= "jdbc:mysql://localhost:3306/try";
		String user="Shreshto";
		String pass="123456";
		try {
		Connection con=DriverManager.getConnection(dburl,user,pass);
		Statement st=con.createStatement();
		
		String query="INSERT INTO teacher"+
					" Values(01,'Rafique');";
		st.executeUpdate(query);
		System.out.println("Inserted");
		
		String query1="INSERT INTO teacher"+
				" Values(02,'Alamgir');";
		st.executeUpdate(query1);
		System.out.println("Inserted");
		
		String query2="INSERT INTO teacher"+
				" Values(03,'Rubel');";
		st.executeUpdate(query2);
		System.out.println("Inserted");
		
		String query3="INSERT INTO teacher"+
				" Values(04,'Zakir');";
		st.executeUpdate(query3);
		System.out.println("Inserted");
		
		String query4="INSERT INTO teacher"+
				" Values(05,'Enam');";
		st.executeUpdate(query4);
		System.out.println("Inserted");
		
		String query5="INSERT INTO teacher"+
				" Values(06,'Jony');";
		st.executeUpdate(query5);
		System.out.println("Inserted");
		
		String query6="Select * from teacher;";
		ResultSet rs=st.executeQuery(query6);
		while (rs.next()) {
			System.out.println(rs.getInt("id")+"  ,  "+rs.getString("name"));
		}
		rs.close();
		
		String query7="Select distinct id,name from teacher;";
		ResultSet rs1=st.executeQuery(query7);
		while (rs1.next()) {
			System.out.println(rs.getInt("id")+"  ,  "+rs.getString("name"));
		}
		rs1.close();
				
		
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
