import java.sql.*;
import javax.swing.*;
public class seven {

	public static void main(String[] args) {
		try {
		String db=JOptionPane.showInputDialog("Database Name(exact) : ");
		String dburl= "jdbc:mysql://localhost:3306/"+db;
		//JPasswordField passwordField = new JPasswordField(10);
		String user = JOptionPane.showInputDialog("Username : ");
		String pass = JOptionPane.showInputDialog("Password : ");
		//String password=passwordField.getPassword().toString();
		try{Connection con=DriverManager.getConnection(dburl,user,pass);
		
		Statement st=con.createStatement();
		String choice = JOptionPane.showInputDialog("Type 1 for query,2 for update,3 for insert, 4 for delete : ");
		
		
		int ch=Integer.parseInt(choice);
		
		if (ch==1)
		{
			try{String quer = JOptionPane.showInputDialog("Write Query : ");
			ResultSet rs=st.executeQuery(quer);
			while(rs.next()) {
				System.out.println(rs.getInt("ID")+"	"+rs.getString("Name"));
			}
			JOptionPane.showMessageDialog(null, "Done");}
			catch(Exception q) {JOptionPane.showMessageDialog(null, "SQL Syntax Error! Type Query Correctly.");}
		
		}
		
		else if(ch==2) {
			try{String updt = JOptionPane.showInputDialog("Write Update : ");
			st.executeUpdate(updt);
			JOptionPane.showMessageDialog(null, "Update Done.");}
			catch(Exception u) {JOptionPane.showMessageDialog(null, "SQL Syntax Error! Type Query Correctly.");}
			
		}
		
		else if (ch==3)
		{
			try {
				JOptionPane.showMessageDialog(null,"Data Successfully Inserted.");}
			catch(Exception i) {JOptionPane.showMessageDialog(null, "SQL Syntax Error! Type Query Correctly.");}
			
		}
		
		else if (ch==4)
		{
			try {
				JOptionPane.showMessageDialog(null,"Data Successfully Deleted.");}
			catch(Exception d) {JOptionPane.showMessageDialog(null, "SQL Syntax Error! Type Query Correctly.");}
			
		}
		
		else {
			JOptionPane.showMessageDialog(null,"Please enter a valid input.");
		}
		
		}
		
	catch(Exception e)
		{e.printStackTrace();}
		}
		
		catch(Exception f) {JOptionPane.showMessageDialog(null, "Something Happened! Rerun the Program.");}
		
		finally {
			JOptionPane.showMessageDialog(null,"Task Done.Rerun the program for further use.");
		}

	}

}
